// Change Title
javascript:var title2 = prompt("New Title"); title = title2; if (title != null); {document.title = title}; void 0;