document.body.style.display = "block";

function selectedBox(){
  document.querySelector(".err").style.display = "none";
}

function openPopup(){
  document.querySelector(".tosBkg").style.display = "flex";
}

function continueToSite(){
  if(document.getElementById("acceptTerms").checked == true){
    document.querySelector(".err").style.display = "none";
    document.querySelector(".tosBkg").style.display = "none";
    //hide tosMsg
    document.querySelector(".tosMsg").setAttribute('id','tosMsgDisappear');
    document.querySelector(".tosMsg").addEventListener("animationend", function() {
      document.querySelector(".tosMsg").style.display = "none";
      document.querySelector(".tosMsg").removeAttribute('id','tosMsgDisappear');
    }, false);
  } else {
    document.querySelector(".err").style.display = "block";
  }
}